import React, { useState } from "react";
import {
  Box,
  Typography,
  useTheme,
  Button,
  Dialog,
  DialogActions,
  DialogContent,
  TextField,
  List,
  ListItem,
  ListItemText,
  Checkbox,
  Chip,
} from "@mui/material";
import { DataGrid } from "@mui/x-data-grid";
import { tokens } from "../../theme";
import { mockDataTeam } from "../../data/mockData"; // Mock data for rows
import Header from "../../components/Header";

const Team = () => {
  const theme = useTheme();
  const colors = tokens(theme.palette.mode);

  const [openDialog, setOpenDialog] = useState(false);
  const [searchQuery, setSearchQuery] = useState("");
  const [selectedOptions, setSelectedOptions] = useState([]);
  const [rows, setRows] = useState(mockDataTeam);
  const [selectedRows, setSelectedRows] = useState([]);

  // Columns definition for the DataGrid
  const columns = [
    { field: "id", headerName: "ID", width: 90 },
    {
      field: "personCount",
      headerName: "Person Count",
      width: 150,
      renderCell: (params) => (
        <Typography color={colors.blueAccent[400]}>{params.row.personCount}</Typography>
      ),
    },
    {
      field: "url",
      headerName: "URL",
      flex: 1,
      renderCell: (params) => (
        <Typography color={colors.grey[300]}>{params.row.url}</Typography>
      ),
    },
    {
      field: "preview",
      headerName: "Preview",
      width: 120,
      renderCell: () => (
        <Button variant="contained" color="primary">Preview</Button>
      ),
    },
    {
      field: "close",
      headerName: "Close",
      width: 120,
      renderCell: () => (
        <Button variant="contained" color="secondary">Close</Button>
      ),
    },
  ];

  // Handle opening and closing the dialog
  const handleOpenDialog = () => setOpenDialog(true);
  const handleCloseDialog = () => {
    setOpenDialog(false);
    setSearchQuery(""); // Reset search query when dialog closes
    setSelectedOptions([]); // Reset selected options for new selection
  };

  // Handle search input change
  const handleSearchChange = (e) => setSearchQuery(e.target.value);

  // Handle selection of options (checkbox change)
  const handleToggleOption = (option) => {
    setSelectedOptions((prev) => {
      if (prev.includes(option)) {
        return prev.filter((item) => item !== option);
      } else {
        return [...prev, option];
      }
    });
  };

  // Handle row selection
  const handleRowSelection = (newSelection) => {
    setSelectedRows(newSelection);
  };

  // Apply selected options to the selected rows
  const applySelectedOptions = () => {
    const updatedRows = rows.map((row) => {
      if (selectedRows.includes(row.id)) {
        return {
          ...row,
          siteControl: selectedOptions.join(", "),
        };
      }
      return row;
    });
    setRows(updatedRows);
    setOpenDialog(false);
    setSearchQuery("");
    setSelectedOptions([]);
  };

  // Handle removing an option from the siteControl field
  const handleRemoveOption = (rowId, optionToRemove) => {
    const updatedRows = rows.map((row) => {
      if (row.id === rowId) {
        const updatedOptions = row.siteControl
          .split(", ")
          .filter((option) => option !== optionToRemove)
          .join(", ");
        return {
          ...row,
          siteControl: updatedOptions,
        };
      }
      return row;
    });
    setRows(updatedRows);
  };

  // Filter options based on the search query
  const filterOptions = ["Option 1", "Option 2", "Option 3", "Option 4"]
    .filter((option) => option.toLowerCase().includes(searchQuery.toLowerCase()))
    .map((option) => ({
      label: option,
      selected: selectedOptions.includes(option),
    }));

  return (
    <Box m="20px">
      <Header title="TEAM" subtitle="Managing Site Data" />

      {/* Buttons in the right corner */}
      <Box display="flex" justifyContent="flex-end" mb={2}>
        <Button variant="contained" color="primary" onClick={handleOpenDialog}>
          Open Search
        </Button>
        <Button
          variant="contained"
          color="secondary"
          sx={{ marginLeft: "10px" }}
          onClick={applySelectedOptions}
        >
          Apply Selected
        </Button>
      </Box>

      {/* Data Grid */}
      <Box
        m="40px 20px 0 0"
        height="100vh"
        sx={{
          "& .MuiDataGrid-root": {
            border: "none",
          },
          "& .MuiDataGrid-cell": {
            borderBottom: "none",
            height: "20px",
          },
          "& .MuiDataGrid-row": {
            height: "px", // Increased row height
          },
          "& .MuiDataGrid-columnHeaders": {
            backgroundColor: colors.blueAccent[700],
            borderBottom: "none",
          },
          "& .MuiDataGrid-virtualScroller": {
            backgroundColor: colors.primary[400],
          },
          "& .MuiDataGrid-footerContainer": {
            borderTop: "none",
            backgroundColor: colors.blueAccent[700],
          },
        }}
      >
        <DataGrid
          checkboxSelection
          rows={rows}
          columns={columns}
          onSelectionModelChange={(newSelection) => handleRowSelection(newSelection)}
        />
      </Box>

      {/* Dialog for searching and selecting options */}
      <Dialog open={openDialog} onClose={handleCloseDialog} fullWidth maxWidth="sm">
        <DialogContent>
          <TextField
            autoFocus
            fullWidth
            variant="outlined"
            label="Search Options"
            value={searchQuery}
            onChange={handleSearchChange}
            sx={{ marginBottom: "10px" }}
          />

          <List>
            {filterOptions.map((option) => (
              <ListItem
                button
                key={option.label}
                onClick={() => handleToggleOption(option.label)}
              >
                <Checkbox checked={option.selected} />
                <ListItemText primary={option.label} />
              </ListItem>
            ))}
          </List>

          <Typography variant="body2" color={colors.grey[500]} mt={2}>
            Selected Options: {selectedOptions.join(", ")}
          </Typography>
        </DialogContent>

        <DialogActions>
          <Button onClick={handleCloseDialog} color="primary">
            Close
          </Button>
          <Button onClick={applySelectedOptions} color="primary">
            Apply
          </Button>
        </DialogActions>
      </Dialog>
    </Box>
  );
};

export default Team;
